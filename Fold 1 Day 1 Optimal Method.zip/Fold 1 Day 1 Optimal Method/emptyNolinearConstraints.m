function [c,ceq]=emptyNolinearConstraints(x)
c=[];
ceq = [];
end
function transformedRefVal1Rt=inputTransform(input,RtRef,k,input_index)
[M,N]=size(RtRef);
transformedRefVal1Rt=zeros(k,N);
for i=1:k
    input(i,input_index);
    RtRef(1,2);
    if input(i,input_index)> (RtRef(1))
        input(i,input_index)= RtRef(1,2);
    elseif  input(i,input_index)< (RtRef(N))   
        input(i,input_index)= RtRef(1,N);
    end
    for j=1:N
        if input(i,input_index)== (RtRef(j))
            transformedRefVal1Rt(i,j)= 1;
        end
    end
    for m=1:N-1
        if (RtRef(m)> input(i,input_index) ) && (input(i,input_index)>RtRef(m+1) )
            transformedRefVal1Rt(i,m+1)= (RtRef(m)-input(i,input_index))/(RtRef(m)-RtRef(m+1));
            transformedRefVal1Rt(i,m)=1-transformedRefVal1Rt(i,m+1);
        end
    end    
end
%return transformedRefVal1Rt
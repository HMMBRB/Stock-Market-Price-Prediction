
function matchingDegree=calMatchingDegreeOne(transformedRefValAnte,attrWeight,noOfRules,AntecedentRef)
matchingDegree=zeros(noOfRules,1);
matchingDegree_k=1;
for i=1:size(AntecedentRef,2)
    transformedRefValAnte(1,i);
    matchingDegree(matchingDegree_k)=(transformedRefValAnte(i).^attrWeight);
    matchingDegree_k=matchingDegree_k+1;
end

return
end
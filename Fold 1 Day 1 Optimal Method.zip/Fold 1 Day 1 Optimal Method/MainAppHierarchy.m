% Stat clear previous data
clear;
clc;
format compact;
global input x1 x4 ...
    AntecedentRef ConsequentRef attrWeight ...
    transformedRefValAnte transformedRefValConse ...
    noOfRules rulebase sizeOfData...
    fid_x1 fid_f1;

fid_x1 = fopen ('output.txt', 'w'); %parameters output file
fid_f1 = fopen ('RMSE.txt', 'w');
%read input file
fid = fopen ('trainData.txt', 'r');
k=0;
input=zeros(800,2);
while ~feof(fid)
    k=k+1;
    line=fgetl(fid);
    input(k,:)=str2num(line);
end
fclose(fid);
input
sizeOfData=k

%read initial rule base for subrule base 1
fid = fopen ('Rulebase.txt', 'r');
noOfRules=0;
while ~feof(fid)
    noOfRules=noOfRules+1;
    %getting the rules line by line
    line=fgetl(fid);
    rule=strsplit(line);
    
    %getting the rule weight for each rules by interation
    rulebase(noOfRules).ruleweight=str2double(rule{2});
    
    %getting antecident1 for each rules by interation
    rulebase(noOfRules).antce=rule(3);

    %getting antecident2 for each rules by interation
    tmp=zeros(1,3);
    tmp(1,1)=str2double(rule{4});
    tmp(1,2)=str2double(rule{5});
    tmp(1,3)=str2double(rule{6});
    rulebase(noOfRules).conse=tmp;
end
fclose(fid);
size(rulebase(:))
% define variables of antecedetns and consequents
x1=[ 1 0.5 0 ];
x4=[ 1 0.5 0 ];

transformedRefValAnte=inputTransform(input,x1,k,1); %input transformation of antecedent
transformedRefValConse=inputTransform(input,x4,k,2); %input transformation of consequent

AntecedentRef=x1;
ConsequentRef=x4;
attrWeight=1;

%-------------------------------------------------
% Optimization of belief degrees of all varaibles
%--------------------------------------------------

lb = zeros(1,12);
ub = ones(1,12);

x0=[ 1 1 1 0 1 0 0 1 0 0 1 0 ];


Aeq= [ 0     0     0     1     1     1     0     0     0     0     0     0;
       0     0     0     0     0     0     1     1     1     0     0     0;
       0     0     0     0     0     0     0     0     0     1     1     1 ]

beq = ones(3,1);
display('starting test------------------------------------------');
objFunBetaOneAll(x0);

options = optimoptions('fmincon','Display','iter','Algorithm','sqp','PlotFcn',{@optimplotx,...
    @optimplotfval,@optimplotfirstorderopt});

[ x, fval, exitflag, output ]=fmincon ( @objFunBetaOneAll, x0, ...
    [], [], Aeq, beq, lb, ub,emptyNolinearConstraints,options);
display(x);